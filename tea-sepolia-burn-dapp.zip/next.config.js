module.exports = {
  reactStrictMode: true
};